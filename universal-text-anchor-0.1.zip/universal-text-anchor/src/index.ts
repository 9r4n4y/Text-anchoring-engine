/**
 * Universal Text Anchor
 *
 * Framework-agnostic identity + geometry primitives for keeping a logical text
 * position in place while documents are reflowed, transformed, edited, or
 * represented by different views. DOM integration is optional; adapters may
 * supply their own capture/resolve/scroll operations.
 */

export type TextAnchor = {
  version: 1;
  /** Caller-defined document identity; prevents cross-document restoration. */
  documentId: string;
  /** Stable semantic identity from an editor/parser, e.g. node id or source URI. */
  blockId?: string;
  /** Position in caller's canonical text coordinate space (normally UTF-16). */
  offset: number;
  /** Text around the point used to recover it after edits or mode changes. */
  exact: string;
  prefix: string;
  suffix: string;
  /** Tie-break hint for repeated text; never overrides exact/context matches. */
  ordinal: number;
  /** Viewport probe position, as a fraction of the visible scrollport. */
  ratio: number;
  /** Anchor glyph top relative to probe, in CSS pixels. */
  delta: number;
  /** Optional opaque, serializable adapter data (e.g. editor path/AST position). */
  metadata?: unknown;
};

export type TextCandidate = {
  text: string;
  /** Offset of candidate.text in canonical document text, if known. */
  offset?: number;
  /** Adapter-local point within text, selected by the resolver. */
  position?: number;
  blockId?: string;
  metadata?: unknown;
};

export type ResolvedPosition = {
  /** First glyph top relative to the scrollport's visible top edge. */
  top: number;
  /** Optional identity returned by the adapter for diagnostics/round-tripping. */
  blockId?: string;
  offset?: number;
};

export interface AnchorAdapter<Root = unknown, Scrollport = unknown> {
  documentId: string;
  /** Capture a canonical text position at viewport coordinate y. */
  capture(root: Root, y: number): TextCandidate | null;
  /** Return candidate representations in the target mode. */
  candidates(root: Root, anchor: TextAnchor): Iterable<TextCandidate>;
  /** Measure the candidate's first glyph top relative to the scrollport top. */
  measure(root: Root, candidate: TextCandidate, scrollport: Scrollport): number | null;
  /** Read/write current scroll position. */
  getScrollTop(scrollport: Scrollport): number;
  setScrollTop(scrollport: Scrollport, value: number): void;
  /** Height of visible scrollport. */
  getViewportHeight(scrollport: Scrollport): number;
  /** Optional layout invalidation subscription; return unsubscribe function. */
  observeLayout?(root: Root, callback: () => void): () => void;
  /** Optional cross-mode/source mapping and application-specific metadata. */
  resolve?(anchor: TextAnchor, candidates: Iterable<TextCandidate>): TextCandidate | null;
}

export type CaptureOptions = {
  documentId: string;
  ratio?: number;
  contextLength?: number;
  metadata?: unknown;
};

const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));

/** Capture a logical anchor using adapter-defined canonical text identity. */
export function captureAnchor<Root, Scrollport>(
  root: Root,
  scrollport: Scrollport,
  adapter: AnchorAdapter<Root, Scrollport>,
  options: CaptureOptions,
): TextAnchor | null {
  if (options.documentId !== adapter.documentId) throw new Error("documentId must match the adapter");
  const ratio = clamp(options.ratio ?? 0.35, 0, 1);
  const y = adapter.getViewportHeight(scrollport) * ratio;
  const hit = adapter.capture(root, y);
  if (!hit || !hit.text.length) return null;
  const offset = clamp(hit.offset ?? 0, 0, hit.text.length);
  const size = Math.max(8, options.contextLength ?? 96);
  const exact = hit.text.slice(offset, offset + size);
  const prefix = hit.text.slice(Math.max(0, offset - size), offset);
  const suffix = hit.text.slice(offset + size, Math.min(hit.text.length, offset + size * 2));
  const ordinal = hit.text.slice(0, offset).split(exact.slice(0, Math.min(24, exact.length))).length - 1;
  const rootTop = adapter.measure(root, hit, scrollport);
  if (rootTop == null) return null;
  return {
    version: 1,
    documentId: options.documentId,
    blockId: hit.blockId,
    offset,
    exact,
    prefix,
    suffix,
    ordinal: Math.max(0, ordinal),
    ratio,
    delta: y - rootTop,
    metadata: options.metadata ?? hit.metadata,
  };
}

/** Resolve an anchor against any target-mode representation. */
export function resolveCandidate<Root, Scrollport>(
  root: Root,
  scrollport: Scrollport,
  adapter: AnchorAdapter<Root, Scrollport>,
  anchor: TextAnchor,
): number | null {
  if (anchor.version !== 1) throw new Error(`Unsupported anchor version: ${anchor.version}`);
  if (anchor.documentId !== adapter.documentId) return null;
  const candidates = [...adapter.candidates(root, anchor)];
  const custom = adapter.resolve?.(anchor, candidates);
  const candidate = custom ?? bestCandidate(anchor, candidates);
  if (!candidate) return null;
  const top = adapter.measure(root, candidate, scrollport);
  if (top == null || !Number.isFinite(top)) return null;
  const viewport = adapter.getViewportHeight(scrollport);
  // measure() returns glyph top relative to the visible scrollport top.
  return adapter.getScrollTop(scrollport) + top + anchor.delta - viewport * anchor.ratio;
}

/** Restore once and optionally hold the position while layout is settling. */
export function restoreAnchor<Root, Scrollport>(
  root: Root,
  scrollport: Scrollport,
  adapter: AnchorAdapter<Root, Scrollport>,
  anchor: TextAnchor,
  options: { pin?: boolean; maxDurationMs?: number; settleFrames?: number } = {},
): { restored: boolean; stop: () => void } {
  let stopped = false;
  let frame = 0;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let unsubscribe: (() => void) | undefined;
  let stableFrames = 0;
  let lastTarget: number | null = null;
  const schedule = typeof requestAnimationFrame === "function"
    ? requestAnimationFrame.bind(globalThis)
    : (callback: FrameRequestCallback) => setTimeout(() => callback(Date.now()), 16) as unknown as number;
  const cancel = typeof cancelAnimationFrame === "function"
    ? cancelAnimationFrame.bind(globalThis)
    : (id: number) => clearTimeout(id);
  const apply = () => {
    if (stopped) return;
    const target = resolveCandidate(root, scrollport, adapter, anchor);
    if (target != null) {
      adapter.setScrollTop(scrollport, target);
      stableFrames = lastTarget != null && Math.abs(target - lastTarget) < 0.5 ? stableFrames + 1 : 0;
      lastTarget = target;
    }
    if (!options.pin || stableFrames >= (options.settleFrames ?? 3)) stop();
    else frame = schedule(apply);
  };
  const stop = () => {
    if (stopped) return;
    stopped = true;
    cancel(frame);
    if (timer) clearTimeout(timer);
    unsubscribe?.();
  };
  // Apply synchronously for immediate layout, then remeasure on animation frames.
  const firstTarget = resolveCandidate(root, scrollport, adapter, anchor);
  const restored = firstTarget != null;
  if (firstTarget != null) adapter.setScrollTop(scrollport, firstTarget);
  if (options.pin) {
    unsubscribe = adapter.observeLayout?.(root, () => { stableFrames = 0; if (!stopped) frame = schedule(apply); });
    timer = setTimeout(stop, options.maxDurationMs ?? 2500);
    frame = schedule(apply);
  } else stop();
  return { restored, stop };
}

/** Score target text candidates without assuming a framework or markup format. */
export function bestCandidate(anchor: TextAnchor, candidates: Iterable<TextCandidate>): TextCandidate | null {
  let best: TextCandidate | null = null;
  let bestScore = -Infinity;
  const needle = anchor.exact.slice(0, Math.min(48, anchor.exact.length));
  for (const item of candidates) {
    if (!item.text) continue;
    const occurrences: number[] = [];
    if (needle) {
      let at = -1;
      while ((at = item.text.indexOf(needle, at + 1)) >= 0) occurrences.push(at);
    }
    if (!occurrences.length && anchor.blockId && item.blockId === anchor.blockId) occurrences.push(clamp(anchor.offset, 0, item.text.length));
    for (const at of occurrences) {
      let score = anchor.blockId && item.blockId === anchor.blockId ? 1000 : 0;
      score += needle.length ? 100 + needle.length : 0;
      const pre = anchor.prefix.slice(-32);
      const suf = anchor.suffix.slice(0, 32);
      if (pre) score += commonSuffix(item.text.slice(0, at), pre) * 2;
      if (suf) score += commonPrefix(item.text.slice(at + needle.length), suf) * 2;
      if (item.offset != null) score -= Math.min(100, Math.abs(item.offset + at - anchor.offset)) / 10;
      score -= Math.abs(occurrences.indexOf(at) - anchor.ordinal) * 3;
      if (score > bestScore) { best = { ...item, position: at }; bestScore = score; }
    }
  }
  return best;
}
function commonPrefix(a: string, b: string): number { let i = 0; while (i < a.length && i < b.length && a[i] === b[i]) i++; return i; }
function commonSuffix(a: string, b: string): number { let i = 0; while (i < a.length && i < b.length && a[a.length - 1 - i] === b[b.length - 1 - i]) i++; return i; }

/** Validate untrusted persisted snapshots before attempting restoration. */
export function isTextAnchor(value: unknown): value is TextAnchor {
  if (!value || typeof value !== "object") return false;
  const a = value as Partial<TextAnchor>;
  return a.version === 1 && typeof a.documentId === "string" && typeof a.offset === "number" &&
    Number.isFinite(a.offset) && typeof a.exact === "string" && typeof a.prefix === "string" &&
    typeof a.suffix === "string" && typeof a.ordinal === "number" && Number.isFinite(a.ordinal) &&
    typeof a.ratio === "number" && Number.isFinite(a.ratio) && typeof a.delta === "number" && Number.isFinite(a.delta);
}

/**
 * Small DOM adapter helper: enumerate text-node runs. A renderer that needs
 * exact source identity should provide candidates mapped to canonical offsets
 * rather than using visible-text offsets directly.
 */
export function domTextCandidates(root: Node, selector = "[data-anchor-id]"): TextCandidate[] {
  const blocks: Element[] = [];
  if (root instanceof Element && root.matches(selector)) blocks.push(root);
  const queryRoot = root as Node & Partial<ParentNode>;
  if (typeof queryRoot.querySelectorAll === "function") blocks.push(...queryRoot.querySelectorAll(selector));
  if (!blocks.length) blocks.push(root as Element);
  const out: TextCandidate[] = [];
  for (const block of blocks) {
    const walker = document.createTreeWalker(block, NodeFilter.SHOW_TEXT, {
      acceptNode: node => node.parentElement?.closest("script,style,[aria-hidden='true']") ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT,
    });
    let text = "";
    for (let node = walker.nextNode(); node; node = walker.nextNode()) text += node.textContent ?? "";
    if (text) out.push({ text, blockId: (block as HTMLElement).dataset?.anchorId });
  }
  return out;
}

/** Example browser adapter for ordinary text-only DOMs. */
export function createDOMTextAdapter(options: {
  documentId: string;
  getScrollTop?: (el: HTMLElement) => number;
  setScrollTop?: (el: HTMLElement, value: number) => void;
  getCandidates?: (root: HTMLElement, anchor: TextAnchor) => Iterable<TextCandidate>;
}): AnchorAdapter<HTMLElement, HTMLElement> {
  const getCandidates = options.getCandidates ?? ((root: HTMLElement) => domTextCandidates(root));
  return {
    documentId: options.documentId,
    capture(root, y) {
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      for (let node = walker.nextNode() as Text | null; node; node = walker.nextNode() as Text | null) {
        const text = node.data;
        for (let i = 0; i < text.length; i++) {
          const range = document.createRange(); range.setStart(node, i); range.setEnd(node, i + 1);
          const rect = range.getBoundingClientRect();
          if (rect.height && rect.top >= root.getBoundingClientRect().top && rect.bottom >= root.getBoundingClientRect().top + y) {
            const block = node.parentElement?.closest<HTMLElement>("[data-anchor-id]");
            return { text, offset: i, blockId: block?.dataset.anchorId };
          }
        }
      }
      return null;
    },
    candidates: getCandidates,
      measure(root, candidate, scrollport) {
      const point = candidate.position ?? candidate.offset ?? 0;
      const needle = candidate.text.slice(point, point + 1);
      if (!needle) return null;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      for (let node = walker.nextNode() as Text | null; node; node = walker.nextNode() as Text | null) {
        const at = node.data.indexOf(needle);
        if (at >= 0) { const range = document.createRange(); range.setStart(node, at); range.setEnd(node, at + 1); return range.getBoundingClientRect().top - scrollport.getBoundingClientRect().top; }
      }
      return null;
    },
    getScrollTop: options.getScrollTop ?? (el => el.scrollTop),
    setScrollTop: options.setScrollTop ?? ((el, value) => { el.scrollTop = value; }),
    getViewportHeight: el => el.clientHeight,
    observeLayout(root, callback) {
      if (typeof ResizeObserver === "undefined") return () => {};
      const observer = new ResizeObserver(callback); observer.observe(root); return () => observer.disconnect();
    },
  };
}
