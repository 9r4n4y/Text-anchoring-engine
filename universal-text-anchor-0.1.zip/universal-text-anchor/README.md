# Universal Text Anchor

A framework-agnostic TypeScript library for preserving **logical text position** through mode changes, reflow, resizing, asynchronous layout, and edits. It is intended to be embedded in any project; React, Markdown, and a particular editor are not required.

## What was extracted from Notenoid

The existing Notenoid editor does not preserve `scrollTop`. It captures the source character under a viewport probe (currently 35% of the scrollport), remembers the character's pixel delta from that probe, and locates that identity in the next representation. Markdown preview text has exact rendered-to-source character maps; edit mode measures the same source character using a hidden textarea mirror. When images/fonts/layout settle, it repeatedly remeasures and pins the target. Syntax characters with no rendered glyph resolve to a nearby mapped glyph; newline positions resolve to nearby painted text. A normalized text needle and source line/block provide fallback matching.

This package extracts the general contract from the editor-specific implementation: a **document identity + logical text point + context + viewport geometry**, with an adapter for each representation. The Markdown source maps and textarea mirror remain renderer/editor responsibilities; those are intentionally not hard-coded here.

## Install / use

Copy this folder into a project, or publish it as a package. It has no runtime dependencies and no React dependency.

```ts
import {
  captureAnchor, restoreAnchor, type AnchorAdapter, type TextCandidate,
} from "./universal-text-anchor";

// Implement once per project/editor family. `capture` returns the canonical
// source text (not merely rendered text) and its UTF-16 offset at viewport y.
const adapter: AnchorAdapter<MyRoot, HTMLElement> = {
  documentId: `document:${doc.id}`,
  capture(root, y) { return editorAdapter.captureCanonicalTextAt(root, y); },
  candidates(root, anchor) { return editorAdapter.candidatesFor(root, anchor); },
  measure(root, candidate) { return editorAdapter.measureCanonicalPoint(root, candidate); },
  getScrollTop: el => el.scrollTop,
  setScrollTop: (el, value) => { el.scrollTop = value; },
  getViewportHeight: el => el.clientHeight,
  observeLayout(root, callback) { return editorAdapter.observeLayout(root, callback); },
  // Optional: use editor-native node IDs/CRDT positions/source maps first.
  resolve(anchor, candidates) { return editorAdapter.resolve(anchor, candidates); },
};

// Before switching to any other mode/view:
const saved = captureAnchor(root, scroller, adapter, {
  documentId: adapter.documentId,
  ratio: 0.35,
  metadata: { mode: currentMode },
});
localStorage.setItem("my-app-anchor", JSON.stringify(saved));

// After the target view is mounted and its adapter/root are ready:
const restored = restoreAnchor(targetRoot, scroller, targetAdapter, saved!, {
  pin: true, maxDurationMs: 2500, settleFrames: 3,
});
// Call restored.stop() early if the component unmounts or navigation is cancelled.
```

### Adapter contract

- `capture(root, y)`: return the canonical text identity and UTF-16 offset at the vertical probe. Capture glyph geometry with a non-collapsed `Range` (or an editor-native equivalent), not browser caret APIs when cross-WebView behavior matters.
- `candidates(root, anchor)`: expose the logical content in the destination mode. Each candidate can carry a stable `blockId`, canonical document offset, and opaque metadata.
- `resolve`: optional preferred resolver. Use exact source maps, stable AST/CRDT node IDs, editor positions, or domain-specific mappings before text-context fallback.
- `measure(root, candidate)`: return the matched glyph top relative to the scrollport top. Include the root's offset if the root is nested.
- `observeLayout`: optional ResizeObserver/editor-layout hook so images, fonts, async embeds, and content changes trigger another measurement.

Use the same canonical coordinate system and `documentId` for all modes of one document. For transformed content (Markdown, rich text, code folding, translated views), map rendered positions to canonical source positions in the adapter. Do not rely on plain visible text when hidden syntax, repeated words, generated text, or edits matter.

## Behavior and portability

- Supports transitions among any number of modes: edit, preview, split, print, mobile, accessibility, canvas, or custom representations, provided adapters can map identity and geometry.
- Anchors are plain JSON and can be persisted, sent across workers, or replayed after navigation. `isTextAnchor` validates untrusted stored snapshots.
- Context/prefix/suffix and occurrence ordinal disambiguate repeated text; stable block IDs and exact adapter resolution take precedence.
- Edits can be recovered approximately from context if offsets move. For exact collaborative/editor edits, pass stable semantic positions or a version-aware transform through adapter `resolve`.
- Geometry is viewport-relative. Raw scroll offsets are never treated as logical identity.
- `restoreAnchor(..., {pin:true})` is bounded by a timeout and can be stopped; it does not create a permanent scroll lock.

## Limits / honest guarantees

No generic library can infer identity perfectly after arbitrary edits or transformations without project-specific semantics. If the original text is deleted, duplicated, hidden, or regenerated, text-only matching can only return a best candidate or fail. Supply stable IDs/source maps/transaction mappings for stronger guarantees. This package reports restoration failure (`restored: false` / `null`) rather than silently claiming the wrong text is the original.

The included `createDOMTextAdapter` is a convenience for ordinary DOM text, not a replacement for editor-specific source maps. Production editor integrations should implement `AnchorAdapter` directly.

## Tests

From the app root: `npx tsx packages/universal-text-anchor/test/core.test.ts`.
