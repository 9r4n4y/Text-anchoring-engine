import assert from "node:assert/strict";
import { bestCandidate, captureAnchor, isTextAnchor, resolveCandidate, restoreAnchor, type AnchorAdapter, type TextCandidate } from "../src/index";

type Root = { candidates: TextCandidate[]; tops: Map<string, number> };
type Port = { scrollTop: number; clientHeight: number };
const root: Root = { candidates: [], tops: new Map() };
const port: Port = { scrollTop: 800, clientHeight: 600 };
root.tops.set("paragraph-a", 0);
const adapter: AnchorAdapter<Root, Port> = {
  documentId: "doc-1",
  capture: (_root, y) => ({ text: "prefix target phrase suffix", offset: 7, blockId: "paragraph-a", metadata: { probe: y } }),
  candidates: r => r.candidates,
  measure: (_r, c) => c.blockId ? root.tops.get(c.blockId) ?? null : null,
  getScrollTop: p => p.scrollTop,
  setScrollTop: (p, value) => { p.scrollTop = value; },
  getViewportHeight: p => p.clientHeight,
};
const snapshot = captureAnchor(root, port, adapter, { documentId: "doc-1", ratio: 0.4, contextLength: 12 });
assert.ok(snapshot);
assert.equal(snapshot.offset, 7);
assert.equal(snapshot.ratio, 0.4);
assert.equal(snapshot.delta, 240); // capture point at 240px; adapter reports top at 0
assert.ok(isTextAnchor(JSON.parse(JSON.stringify(snapshot))));

root.candidates = [
  { text: "unrelated target phrase suffix", blockId: "paragraph-b", offset: 100 },
  { text: "prefix target phrase suffix", blockId: "paragraph-a", offset: 6 },
];
root.tops.set("paragraph-a", 350);
const matched = bestCandidate(snapshot, root.candidates);
assert.equal(matched?.blockId, "paragraph-a", "stable semantic block wins among repeated text");
assert.ok(resolveCandidate(root, port, adapter, snapshot) != null);
const result = restoreAnchor(root, port, adapter, snapshot, { pin: false });
assert.equal(result.restored, true);
assert.equal(port.scrollTop, 800 + 350 + 240 - 600 * 0.4);
assert.equal(resolveCandidate(root, port, { ...adapter, documentId: "other-doc" }, snapshot), null);
assert.equal(bestCandidate(snapshot, [{ text: "no matching content", blockId: "x" }]), null);
console.log("PASS universal-text-anchor core tests");
